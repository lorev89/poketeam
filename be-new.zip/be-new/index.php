<?php

require_once __DIR__ . '/src/Database.php';
require_once __DIR__ . '/src/controllers/ProductController.php';
require_once __DIR__ . '/src/controllers/CategoryController.php';
require_once __DIR__ . '/src/model/Product.php';
require_once __DIR__ . '/src/model/Category.php';
require_once __DIR__ . '/src/utilities/Utils.php';

use Controller\ProductController;
use Controller\CategoryController;


$host = $_SERVER['HTTP_HOST'];
$requestUri = $_SERVER['REQUEST_URI'];
$method = $_SERVER['REQUEST_METHOD'];
$parsedUrl = parse_url($requestUri)["path"];


/** ROUTING */
switch (true) {

    /** GET /api/product/list*/
    case (preg_match('#/api/product/list$#', $parsedUrl) && $method === 'GET'):
        ProductController::list();
        break;

    /** POST /api/product/create */
    case (preg_match('#/api/product/create$#', $parsedUrl) && $method === 'POST'):
        
        ProductController::create();
        break;

    /** GET api/product/:id/detail */
    case (preg_match('#/api/product/(\d+)/detail$#', $parsedUrl, $matches) && $method === 'GET'):

        ProductController::detail($matches[1]);
        break;

    /** PUT api/product/:id/update */
    case (preg_match('#/api/product/(\d+)/update$#', $parsedUrl, $matches) && $method === 'PUT'):

        ProductController::update($matches[1]);
        break;

    /** DELETE api/product/:id/delete */
    case (preg_match('#/api/product/(\d+)/delete$#', $parsedUrl, $matches) && $method === 'DELETE'):
        
        ProductController::delete($matches[1]);
        break;

    /** GET api/category/list */
    case (preg_match('#/api/category/list$#', $parsedUrl, $matches) && $method === 'GET'):
        
        CategoryController::list();
        break;

    default:
        header("Content-Type: application/json");
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'Not Found']);
        break;
}

?>
