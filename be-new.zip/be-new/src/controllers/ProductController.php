<?php
namespace Controller;

use Database\Database;
use Model\Product;
use Model\Category;
use Utilities\Utils;

class ProductController {
    public static function list() {
        try {
            $connection = Database::getInstance()->getConnection();

            $itemsPerPage = $_GET['items_per_page'] ?? 10;
            $page = $_GET['page'] ?? 1;
            $searchText = $_GET['name'] ?? '';
            $categoryId = $_GET['category_id'] ?? null;

            $results =  Product::list($connection, $page, $itemsPerPage, $searchText, $categoryId);
            $connection->close();

            header("Content-Type: application/json");
            echo json_encode([
                'code' => 200,
                'data' => $results
            ]);
        } catch (\Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
    }

    public static function create() {
        try {
            $jsonData = file_get_contents('php://input');
            $body = json_decode($jsonData, true);

            $connection = Database::getInstance()->getConnection();
            $categoryId = !empty($body['category_name']) ? Category::createIfNotExists($connection, $body['category_name']) :  $body['category_id'];

            if (isset($body["image"])) {
                $imagePath = Utils::createFromBase64($body["image"]);
            }

            $created = Product::create($connection,[
                'code' => $body['code'],
                'name' => $body['name'],
                'price' => $body['price'],
                'amount' => $body['amount'],
                'category_id' => $categoryId,
                'img_path' => $imagePath ?? '',
            ]);
            $connection->close();

            header("Content-Type: application/json");
            echo json_encode([
                'result' => $created ?? false
            ]);
        } catch (\Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
    }
    
    public static function detail($productId) {
        try {
            $connection = Database::getInstance()->getConnection();
            $productId = $productId ? intval($productId) : '';

            if (!($productId > 0)) {
                throw new \Exception('Invalid id');
            }

            $data = Product::getById($connection, $productId);

            header("Content-Type: application/json");
            echo json_encode([
                'code' => 200,
                'data' => $data
            ]);
        } catch (\Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
    }

    public static function update($productId) {
        try {
            $jsonData = file_get_contents('php://input');
            $body = json_decode($jsonData, true);

            $productId = $productId ? intval($productId) : '';

            if (!($productId > 0)) {
                throw new \Exception('Invalid id');
            }

            $connection = Database::getInstance()->getConnection();
            $product = Product::getById($connection,  $productId);

            if (isset($body['code']) && $body['code'] != $product['code']) 
                $product['code'] = $body['code'];
            
            if (isset($body['name'])) 
                $product['name'] =  $body['name'];
            
            if (isset($body['price']))
                $product['price']=  $body['price'];

            if (isset($body['amount']))
                $product['amount'] =  $body['amount'];

            if (isset($body['category_id']))
                $product['category_id'] =  $body['category_id'];

            if (isset($body['category_name']) && !empty($body['category_name'])) {
                $product['category_id'] = Category::createIfNotExists($connection, $body['category_name']);
            }
        
            if (isset($body['image'])) {
                $product['img_path'] = Utils::createFromBase64($body["image"]);
            }

            $updated = Product::update($connection,$productId,[
                'code' => $body['code'],
                'name' => $body['name'],
                'price' => $body['price'],
                'amount' => $body['amount'],
                'category_id' => $product['category_id'],
                'img_path' => $product['img_path']
            ]);
            $connection->close();
            
            header("Content-Type: application/json");
            echo json_encode([
                'result' => $updated ?? false
            ]);
        } catch (\Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
    }

    public static function delete(string $productId) {
        try {
            $connection = Database::getInstance()->getConnection();
            $product = Product::getById($connection, $productId);
            $results =  Product::delete($connection, $productId);
           
            if (!empty($product['category']) && !empty($product['category']['id']))
              $deletedCategoy = Category::deleteIfNotReferenced($connection, $product['category']['id']);

            $connection->close();

            header("Content-Type: application/json");
            echo json_encode([
                'code' => 200,
                'data' => ["deleted" => $results]
            ]);
        } catch (\Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
    }
}