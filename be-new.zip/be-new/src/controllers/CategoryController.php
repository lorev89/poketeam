<?php

namespace Controller;

use Database\Database;
use Model\Category;

class CategoryController {
    public static function list() {
        try {
            $connection = Database::getInstance()->getConnection();

            $results =  Category::list($connection);
            $connection->close();

            header("Content-Type: application/json");
            echo json_encode([
                'data' => $results
            ]);
        } catch (\Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
    }
}