<?php

namespace Model;

class Product
{
    public static function list($connection, $page = 0, $itemsPerPage = 10, $searchText = '', $categoryId = null)
    {
        $offset = ($page - 1) * $itemsPerPage;

        $sql = "SELECT products.*, categories.name AS category_name 
                FROM products 
                JOIN categories ON products.category_id = categories.id ";
        $sqlTypes = "";
        $bindVars = [];

        $countSql = "SELECT COUNT(*) as total_count 
                FROM products 
                JOIN categories ON products.category_id = categories.id";

        $sqlWhere = "";
        if (!empty($searchText) || !empty($categoryId)) {
            $sqlWhere .= " WHERE ";
        }

        if (!empty($searchText)) {
            $likeSearchText = '%' . $searchText . '%';
            $sqlWhere .= "(MATCH(products.name) AGAINST(?) OR products.name LIKE ?) ";
            $sqlTypes .= "ss";
            $bindVars = array_merge($bindVars, [$searchText, $likeSearchText]);
        }

        if (!empty($categoryId)) {
            if (!empty($searchText)) {
                $sqlWhere .= " AND ";
            }
            $sqlWhere .= "(products.category_id = ? )";
            $sqlTypes .= "i";
            $bindVars[] = $categoryId;
        }

        $sql .= $sqlWhere;
        $countSql .= $sqlWhere;

        $countStmt = $connection->prepare($countSql);
        if (!empty($sqlTypes)) {
            $countStmt->bind_param($sqlTypes, ...$bindVars);
        }

        $sql .= "LIMIT ?,?";
        $sqlTypes .= "ii";
        $bindVars = array_merge($bindVars, [$offset, $itemsPerPage]);

        $stmt = $connection->prepare($sql);
        $stmt->bind_param($sqlTypes, ...$bindVars);


        $stmt->execute();
        $result = $stmt->get_result();

        $countStmt->execute();
        $countResult = $countStmt->get_result();

        $totalCountRow = $countResult->fetch_assoc();
        $totalCount = (int)$totalCountRow['total_count'];

        $lastPage = ceil($totalCount / $itemsPerPage);

        $products = $result->fetch_all(MYSQLI_ASSOC);

        $countStmt->close();
        $stmt->close();

        return [
            'data' => $products,
            'last_page' => $lastPage
        ];
    }

    public static function getById($connection, $id)
    {
        $sql = "SELECT products.*,  c.id AS category_id,c.name AS category_name FROM products 
            JOIN categories c ON products.category_id = c.id 
            WHERE products.id = ?";

        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $id);

        $stmt->execute();

        $result = $stmt->get_result();
        $product = $result->fetch_assoc();

        $stmt->close();

        if (empty($product))
            throw new \Exception("invalid product id");

        /** =>  formatto per evitare refactor nel FE  :) */
        $product["category"] = [
            "id" => $product["category_id"],
            "name" => $product["category_name"]
        ];
        unset($product["category_id"]);
        unset($product["category_name"]);

        return $product;
    }

    public static function create($connection, $data)
    {
        $sql = "INSERT INTO products (code, name, price, amount, category_id, img_path, created_at, updated_at) 
                VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())";

        $stmt = $connection->prepare($sql);
        $stmt->bind_param(
            "ssdiis",
            $data['code'],
            $data['name'],
            $data['price'],
            $data['amount'],
            $data['category_id'],
            $data['img_path']
        );

        $stmt->execute();
        $stmt->close();

        return true;
    }
    public static function update($connection, $productId, $data)
    {
        $sql = "UPDATE products 
                SET code = ?, name = ?, price = ?, amount = ?, category_id = ?, img_path = ?, updated_at = NOW() 
                WHERE id = ?";

        $stmt = $connection->prepare($sql);
        $stmt->bind_param(
            "ssdiisi",
            $data['code'],
            $data['name'],
            $data['price'],
            $data['amount'],
            $data['category_id'],
            $data['img_path'],
            $productId
        );

        $stmt->execute();
        $stmt->close();

        return true;
    }

    public static function delete($connection, $id)
    {
        $sql = "DELETE FROM products WHERE id = ?";

        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();

        $affectedRows = $stmt->affected_rows;
        $stmt->close();

        if ($affectedRows > 0) {
            return true;
        } else {
            return false;
        }
    }
}
