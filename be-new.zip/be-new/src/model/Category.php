<?php

namespace Model;

class Category {
    public static function list($connection) {
        $stmt = $connection->prepare("SELECT id, name FROM categories");
        
        $stmt->execute();
        $result = $stmt->get_result();

        $categories = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        return $categories;
    }

    public static function createIfNotExists($connection, $name) {
        $stmt = $connection->prepare("SELECT id FROM categories WHERE name = ?");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return $row['id'];
        }

        $stmt = $connection->prepare("INSERT INTO categories (name) VALUES (?)");
        $stmt->bind_param("s", $name);

        $stmt->execute();
        $stmt->close();

        return $connection->insert_id;
    }

    public static function deleteIfNotReferenced($connection, $id) {
        $sql = "
            DELETE categories 
            FROM categories 
            LEFT JOIN products  ON categories.id = products.category_id 
            WHERE categories.id = ? AND products.id IS NULL
        ";
    
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
    
        return $stmt->affected_rows > 0; 
    }
}