<?php

namespace Utilities;

class Utils
{

  public static function createFromBase64($base64)
  {
    if (!preg_match('/^data:image\/(\w+);base64,/', $base64, $type)) {
      throw new \Exception('Invalid base64 string.');
    }
    $extension = strtolower($type[1]);
    $filename = uniqid() . '.' . $extension;

    $data = substr($base64, strpos($base64, ',') + 1);
    $data = base64_decode($data);
    if ($data === false) {
      throw new \Exception('Base64 value is not valid.');
    }

    $directory = __DIR__ . '/../../public/images';
    if (!is_dir($directory)) {
      mkdir($directory, 0755, true);
    }

    $filePath = $directory . '/' . $filename;
    file_put_contents($filePath, $data);

    return $filename;
  }
}
