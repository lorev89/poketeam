<?php

declare(strict_types=1);

namespace App\Application\Controllers;

use App\Application\Models\Category;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Application\Models\Product;
use App\Application\Utilities\Utils;
use App\Application\Models\Image;

class ProductController
{
    public static function list(Request $request, Response $response, $args): Response
    {
        try {

            $queryParams = $request->getQueryParams();
            $itemsPerPage = $queryParams['items_per_page'] ?? 10;
            $page = $queryParams['page'] ?? 1;

            $searchText = $queryParams['name'] ?? '';
            $categoryId = $queryParams['category_id'] ?? null;

            $products = Product::list($page, $itemsPerPage, $searchText, $categoryId); // Fetch all products
            $data = $products->toArray();

            return Utils::successResponse($response, $data);
        } catch (\Exception $e) {
            return Utils::errorResponse($response, $e->getMessage(), 500);
        }
    }
    public static function create(Request $request, Response $response): Response
    {
        try {

            $body = $request->getParsedBody();


            $categoryId = !empty($body['category_name']) ? Category::createIfNotExists($body['category_name']) :  $body['category_id'];

            if (isset($body["image"])) {
                $imagePath = Utils::createFromBase64($body["image"]);
            }

            $product = new Product();
            $product->code = $body['code'];
            $product->name =  $body['name'];
            $product->price =  $body['price'];
            $product->amount =  $body['amount'];
            $product->category_id =  $categoryId;
            $product->img_path = $imagePath ?? null;

            $product->save();

            return Utils::successResponse($response, ['created' => $product]);
        } catch (\Exception $e) {
            return Utils::errorResponse($response, $e->getMessage(), 500);
        }
    }

    public static function detail(Request $request, Response $response, $args)
    {
        try {
            $id = $args['id'] ? intval($args['id']) : '';
            if (!($id > 0)) {
                throw new \Exception('Invalid id');
            }

            $data = Product::getById($id);

            return Utils::successResponse($response, $data->toArray());
        } catch (\Exception $e) {
            return Utils::errorResponse($response, $e->getMessage(), 500);
        }
    }

    public static function update(Request $request, Response $response, $args)
    {
        try {
            $id = $args['id'] ? intval($args['id']) : '';
            if (!($id > 0)) {
                throw new \Exception('Invalid id');
            }

            $body = $request->getParsedBody();

            $product = Product::getById($id);

            if (isset($body['code']) && $body['code'] != $product->code) 
                $product->code = $body['code'];
            
            if (isset($body['name'])) 
                $product->name =  $body['name'];
            
            if (isset($body['price']))
                $product->price =  $body['price'];

            if (isset($body['amount']))
                $product->amount =  $body['amount'];

            if (isset($body['category_id']))
                $product->category_id =  $body['category_id'];

            if (isset($body['category_name']) && !empty($body['category_name'])) {
                $product->category_id = Category::createIfNotExists($body['category_name']);
            }
        
            if (isset($body['image'])) {
                $product->img_path = Utils::createFromBase64($body["image"]);
            }
           
            $product->save();

            return Utils::successResponse($response,$product->toArray());
        } catch (\Exception $e) {
            return Utils::errorResponse($response, $e->getMessage(), 500);
        }
    }

    public static function delete(Request $request, Response $response, $args)
    {
        try {
            $id = $args['id'] ? intval($args['id']) : '';
            if (!($id > 0)) {
                throw new \Exception('Invalid id');
            }

            $product = Product::getById($id);

            $categoryId = $product->category_id;
            $deleted  = $product->delete();

            if ($deleted) {
                Category::deleteIfNotReferenced($categoryId);
            }

            return Utils::successResponse($response, ['deleted' => $deleted]);
        } catch (\Exception $e) {
            return Utils::errorResponse($response, $e->getMessage(), 500);
        }
    }
}
