<?php

namespace App\Application\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $table = 'categories';
    protected $primaryKey = 'id';
    protected $fillable = ['name'];
    public $timestamps = true;

    public function products()
    {
        return $this->hasMany(Product::class);
    }

    public static function createIfNotExists(string $name)
    {
        $created = self::firstOrCreate(
            ['name' => $name],  
            ['name' => $name]   
        );

        return $created->id;
    }

    public static function deleteIfNotReferenced($id)
    {
        $category = self::find($id);

        if (!$category) {
            throw new \Exception('Category not found.');
        }

        var_dump( $category->products()->exists() );
        $isReferenced = $category->products()->exists();

        if (!$isReferenced) {
            $deleted = $category->delete();
        }

        return $deleted ?? false;
    }
}
