<?php

namespace App\Application\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = 'products';
    protected $primaryKey = 'id';
    protected $fillable = ['code', 'name', 'price', 'amount', 'category_id', 'img_path'];
    public $timestamps = true;

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public static function list($page = 0, $itemsPerPage = 10, $searchText = '', $categoryId = null) {

        $query =  self::select('products.*', 'categories.name as category_name')
        ->join('categories', 'products.category_id', '=', 'categories.id');

        if ($searchText != '') {
            $query->where(function ($q) use ($searchText) {
            $q->whereRaw("MATCH(products.name) AGAINST(? IN NATURAL LANGUAGE MODE)", [$searchText])
              ->orWhere('products.name', 'LIKE', '%' . $searchText . '%');
        });}

        if ($categoryId) {
            $query->where('products.category_id', $categoryId);
        }
    
        $products = $query->paginate($itemsPerPage, ['*'], 'page', $page);

        return $products;
    }

    public static function getById($id)   {
        $product = self::with(['category'])->find($id);

        if (!$product) {
            throw new \Exception("Product not found");
        }

        return $product;
    }
}
