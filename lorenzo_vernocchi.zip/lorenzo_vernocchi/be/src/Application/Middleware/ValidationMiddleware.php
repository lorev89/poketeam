<?php namespace App\Application\Middleware;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface;
use Swaggest\JsonSchema\Schema;
use Swaggest\JsonSchema\Exception\ValidationException;

class ValidationMiddleware
{
    public function __invoke(Request $request, RequestHandlerInterface $handler): Response
    {
        $parsedBody = json_decode($request->getBody());

        $schemas = [
            '/api/products/create' => '{
                "type": "object",
                "properties": {
                    "code": {"type": "string"},
                    "name": {"type": "string"},
                    "price": {"type": "number"},
                    "amount": {"type": "integer"},
                    "category_id": {"type": "integer"},
                    "img": {
                        "type": "string",
                        "pattern": "^data:image/(jpeg|jpg|png|gif);base64,[A-Za-z0-9+/=]+$"
                    }
                },
                "required": ["code", "name", "price", "amount", "category_id"]
            }',
            'api/products/update' => '{
                "type": "object",
                "properties": {
                    "code": {"type": "string"},
                    "name": {"type": "string"},
                    "price": {"type": "number"},
                    "amount": {"type": "integer"},
                    "category_id": {"type": "integer"},
                    "img": {
                        "type": "string",
                        "pattern": "^data:image/(jpeg|jpg|png|gif);base64,[A-Za-z0-9+/=]+$"
                    }
                },
                "required": ["code", "name", "price", "amount", "category_id"]
            }',
        ];

        $route = $request->getUri()->getPath();

        if ($route && isset($schemas[$route])) {
            try {
                $schema = Schema::import(json_decode($schemas[$route]));
                $schema->in($parsedBody);
            } catch (\Exception $e) {
                throw new \Exception('Invalid body');
            }
        }

        return $handler->handle($request); 
    }
}
