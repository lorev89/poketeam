<?php

namespace App\Application\Utilities;

use Slim\Psr7\Response;



class Utils {

    public static function successResponse(Response $response, array $data, int $code = 200, array $pager = []): Response
{
  $returnValue = [
    'code' => $code,
    'result' => true,
    'timestamp' => time(),
    'data' => $data
  ];

  if (!empty($pager)) {
    $returnValue['pager'] = $pager;
  }

  
  $response->getBody()->write(json_encode($returnValue));
  return $response
             ->withHeader('Content-Type', 'application/json');
}

public static function errorResponse(Response $response, string $message, int $code = 0): Response {
    $returnValue = [
        'code' => $code,
        'result' => false,
        'timestamp' => time(),
        'data' => [
          'message' => $message
        ]
      ];

    $response->getBody()->write(json_encode($returnValue));
    return $response
        ->withHeader('Content-Type', 'application/json');
}

public static function createFromBase64($base64)
{
    // Check if the base64 string is valid
    if (preg_match('/^data:image\/(\w+);base64,/', $base64, $type)) {
        // Get the file extension
        $extension = strtolower($type[1]); // jpg, png, gif

        // Generate a unique filename
        $filename = uniqid() . '.' . $extension;

        // Decode the base64 string
        $data = substr($base64, strpos($base64, ',') + 1);
        $data = base64_decode($data);

        if ($data === false) {
            throw new \InvalidArgumentException('Base64 value is not valid.');
        }

        $directory = __DIR__ . '/../../../public/images'; // Adjust path as needed

        // Create the directory if it doesn't exist
        if (!is_dir($directory)) {
            mkdir($directory, 0755, true); // Create the directory with proper permissions
        }

        $filePath = $directory . '/' . $filename;
        file_put_contents($filePath, $data);


        return $filename;
    }

    throw new \InvalidArgumentException('Invalid base64 string.');
}
}