<?php

use App\Application\Controllers\CategoryController;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\App;
use App\Application\Models\Product;
use App\Application\Models\Category;
use App\Application\Middleware\ValidationMiddleware;
use App\Application\Controllers\ProductController;

return function (App $app): void {
    
    $app->options('/{routes:.*}', function (Request $request, Response $response) {
        // CORS Pre-Flight OPTIONS Request Handler
        return $response;
    });

    
$app->get('/api/product/list', [ProductController::class, 'list']);

$app->get('/api/product/{id}/detail', [ProductController::class, 'detail']);

$app->put('/api/product/{id}/update', [ProductController::class ,'update']);

$app->delete('/api/product/{id}/delete', [ProductController::class, 'delete']);

$app->post('/api/product/create', [ProductController::class, 'create']);//->add(middleware: new ValidationMiddleware());;

$app->get('/api/category/list',[CategoryController::class, 'list']);

};
