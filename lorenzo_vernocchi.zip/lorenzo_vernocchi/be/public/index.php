<?php

declare(strict_types=1);

use App\Application\Handlers\HttpErrorHandler;
use Slim\Factory\AppFactory;
use Slim\Factory\ServerRequestCreatorFactory;
use Illuminate\Database\Capsule\Manager as Capsule;

error_reporting(E_ALL & ~E_DEPRECATED);

require __DIR__ . '/../vendor/autoload.php';

$app = AppFactory::create();

/** DB connection */
$capsule = new Capsule();
$capsule->addConnection([
    'driver' => 'mysql',
    'host' => 'mysql',
    'port' => 3306, 
    'database' => 'test',
    'username' => 'root',       
    'password' => 'root',       
    'charset' => 'utf8',
    'collation' => 'utf8_unicode_ci',
    'prefix' => '',
]);

$capsule->setAsGlobal();
$capsule->bootEloquent();

/** ROUTES **/
$routes = require __DIR__ . '/../app/routes.php';
$routes($app);

$serverRequestCreator = ServerRequestCreatorFactory::create();
$request = $serverRequestCreator->createServerRequestFromGlobals();


$callableResolver = $app->getCallableResolver();
$responseFactory = $app->getResponseFactory();
$errorHandler = new HttpErrorHandler($callableResolver, $responseFactory);

$app->addRoutingMiddleware();
$app->addBodyParsingMiddleware();

$errorMiddleware = $app->addErrorMiddleware(true, false, false);
$errorMiddleware->setDefaultErrorHandler($errorHandler);


$app->run();

