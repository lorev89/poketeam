BE:
  Realizzato con Slim Framework
  public/images è la folder in cui sono storati i file caricati su server
  Nella root del progetto è presente un docker-compose.yml per servire backend e database (comando docker-compose up)
  La configurazione della connessione a db è da effettuare a riga 18 del file public/index.php (attualmente impostato per la connessione al container mysql)
  Se non viene utilizzato il container è necessario abilitare mod_rewrite e mod_headers di apache

FE:
  Single page application realizzata con Knockoutjs
  Nella root è presente un .htaccess per il redirect ad index.html
  Per configurare il base url per l'integrazione con il be è necessario configurare BASE_URL nel file config.js presente nella root

DB:
  test_dump.sql



È presente una collezione postman usata in fase di sviluppo per testare le api esposte dal backend


Grazie
Buone feste!
