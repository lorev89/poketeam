/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.6.2-MariaDB, for osx10.19 (arm64)
--
-- Host: 127.0.0.1    Database: test
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(13,'Electronics','2024-12-29 21:31:59','2024-12-29 21:31:59'),
(14,'Home','2024-12-29 21:31:59','2024-12-29 21:31:59'),
(16,'Sports','2024-12-29 21:31:59','2024-12-29 21:31:59'),
(17,'Beauty','2024-12-29 21:31:59','2024-12-29 21:31:59'),
(18,'Clothing','2024-12-29 21:52:56','2024-12-29 21:52:56');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `img_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `category_id` (`category_id`),
  FULLTEXT KEY `fulltext_name_index` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(73,'001','Smartphone One',150.00,10,13,'6771c0059a6cb.jpeg','2024-12-29 21:32:53','2024-12-29 21:32:53'),
(74,'002','Tablet One',199.00,11,13,'6771c02fb47e0.jpeg','2024-12-29 21:33:35','2024-12-29 21:33:35'),
(75,'003','Laptop One',500.00,2,13,'6771c074769be.jpeg','2024-12-29 21:34:44','2024-12-29 21:34:44'),
(76,'004','Laptop Two',699.00,15,13,'6771c0d5a92f9.jpeg','2024-12-29 21:36:21','2024-12-29 21:36:21'),
(77,'005','Coffee Table',150.00,2,14,'6771c11084efc.jpeg','2024-12-29 21:37:20','2024-12-29 21:37:20'),
(78,'006','Coffee Table Two',1500.00,1,14,'6771c14515b24.webp','2024-12-29 21:38:13','2024-12-29 21:38:13'),
(79,'007','Chair',160.00,16,14,'6771c1ee5b26e.jpeg','2024-12-29 21:41:02','2024-12-29 21:41:02'),
(80,'008','Chaise Longue ',2000.00,1,14,'6771c240e8ad2.jpeg','2024-12-29 21:42:25','2024-12-29 21:42:25'),
(81,'009','Vase',35.00,23,14,'6771c2b7ccba0.jpeg','2024-12-29 21:44:23','2024-12-29 21:44:23'),
(82,'010','Cosmetic',5.00,36,17,'6771c34840a5b.jpeg','2024-12-29 21:46:48','2024-12-29 21:46:48'),
(85,'011','Parka',199.00,10,18,'6771c5337f013.jpeg','2024-12-29 21:54:59','2024-12-29 21:54:59'),
(86,'012','Pullover',50.00,33,18,'6771c58d284df.jpeg','2024-12-29 21:55:43','2024-12-29 21:56:29'),
(87,'013','Pullover Two',33.00,23,18,'6771c5763bc7f.jpeg','2024-12-29 21:56:06','2024-12-29 21:56:06'),
(88,'014','Hoodie',20.00,40,18,'6771c5c9c0496.jpeg','2024-12-29 21:57:29','2024-12-29 21:57:29'),
(89,'015','Scarf',14.00,45,18,'6771c5f466439.jpeg','2024-12-29 21:58:12','2024-12-29 21:58:12'),
(90,'016','Vase Two',70.00,33,14,'6771c6354fd8c.jpeg','2024-12-29 21:59:17','2024-12-29 21:59:17'),
(91,'017','Skateboard',60.00,45,16,'6771c7c16911b.jpeg','2024-12-29 22:05:53','2024-12-29 22:05:53'),
(92,'018','Sofa',2500.00,3,14,'6771c7dc13eec.webp','2024-12-29 22:06:20','2024-12-29 22:06:20'),
(93,'019','Table Tennis Racket',16.00,46,16,'6771c80c2582d.jpeg','2024-12-29 22:07:08','2024-12-29 22:07:08'),
(94,'020','Table Tennis table',300.00,1,16,'6771c836c750c.png','2024-12-29 22:07:50','2024-12-29 22:07:50'),
(95,'021','Basket',30.00,31,16,'6771c856e95e2.webp','2024-12-29 22:08:23','2024-12-29 22:08:23'),
(96,'022','Beautycase',23.00,47,17,'6771c8a342747.jpeg','2024-12-29 22:09:39','2024-12-29 22:09:39');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

--
-- Dumping routines for database 'test'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2024-12-29 23:12:28
