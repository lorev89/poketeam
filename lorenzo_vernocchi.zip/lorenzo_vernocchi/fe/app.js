import * as $Lib from 'jquery';
import * as koLib from 'knockout';
import * as SammyLib from 'sammy/lib/sammy';
import * as SumoSelectLib from 'sumoselect'
import config from './config.js';

let app

$(document).ready(function () {
    $('#categorySelectAdd').SumoSelect({
        search: true,
        searchText: 'Enter here.',
        noMatch: 'No Matches for "{0}"'
    });
});

function AppViewModel() {
    var self = this;
    this.userRating = ko.observable(null);

    self.currentView = ko.observable('home');
    self.imgBasePath = ko.observable(`${config.BASE_URL}/public/images/`) //TODO: /public/images in BE

    /** home observables */
    self.products = ko.observableArray([]);
    self.categories = ko.observableArray([])
    self.searchName = ko.observable()
    self.selectedCategory = ko.observable()

    self.staticOptions = ko.observableArray([
        { id: 0, name: 'Any' }
    ]);

    self.combinedCategories = ko.computed(function() {
        return self.staticOptions().concat(self.categories());
    });

    /** pager */
    self.currentPage = ko.observable(1);
    self.numberOfpages = ko.observable(1);
    self.itemsPerPage = ko.observable(10);
    self.totalPages = ko.observable()

    /** detail and update observables */
    self.productId = ko.observable(null); 
    self.selectedProduct = ko.observable();
    self.imagePreview = ko.observable()

    self.newCategory = ko.observable('');

    self.suggestions = ko.observableArray([])
    self.categoryInput = ko.observable('');

    /** create product */
    self.newProduct = ko.observable({
        name: ko.observable(''),
        code: ko.observable(''),
        price: ko.observable(0),
        amount: ko.observable(0),
        category_id: ko.observable(null),
        image: ko.observable(null) 
    });

    self.currentTemplate = ko.computed(function () {
        switch (self.currentView()) {
            case 'home':
                return 'home-template';
            case 'about':
                return 'about-template';
            case 'contact':
                return 'contact-template';
            case 'product-detail':
                return 'product-detail-template';
            case 'product-edit':
                return 'product-edit-template';
            case 'product-add':
                return 'product-add-template';
            default:
                return '404-template';
        }
    });


    self.changeView = function (view) {
        self.currentView(view);
    };

    self.loadProducts = function () {
        self.currentPage(self.currentPage() ?? 1)
        let url = `${config.BASE_URL}/api/product/list?page=${self.currentPage()}`


        if (self.itemsPerPage()) {
            url = `${url}&items_per_page=${self.itemsPerPage()}`
        }

        if (self.searchName() != null) {
            url = `${url}&name=${self.searchName()}`
        }

        if (self.selectedCategory() != null) {
            url = `${url}&category_id=${self.selectedCategory()}`
        }

        $.getJSON(url)
            .then(function (response) {
                if (!response.data || !response.data.data) {
                    throw new Error('No items found in response');
                }

                const data = response.data
                const products = data.data

                if (data.last_page) {
                    self.totalPages(data.last_page)
                }

                self.products(products);
            })
            .catch(function (error) {
                console.error("Failed to load products:", error.message);
                alert("An error occurred: " + error.message);
            });

    };

    self.loadCategories = function () {
        $.getJSON(`${config.BASE_URL}/api/category/list`, function (response) {

            if (!response.data) {
                throw new Error('No items found in response');
            }

            const data = response.data

            self.categories(data);
        }).fail(function () {
            console.error("Failed to load products.");
        });

        console.log( self.combinedCategories())
    };

    self.updateSuggestions = function () {
        const query = self.categoryInput().toLowerCase();

        if (query.length > 0) {
            const filteredCategories = self.categories().filter(function (category) {
                return category.name.toLowerCase().includes(query);
            });
            self.suggestions(filteredCategories);
        } else {
            self.suggestions([]);
        }
    };

    self.loadProductDetails = function () {

        let productId = self.productId()
        $.getJSON(`${config.BASE_URL}/api/product/${productId}/detail`)
            .then(function (response) {
                if (response.code === 200 && response.data) {
                    self.selectedProduct(response.data);
                } else {
                    alert("Failed to load product details.");
                }
            })
            .catch(function (error) {
                console.error("Failed to load product details:", error.message);
                alert("An error occurred while loading product details.");
            });
    };

    self.applyFilters = () => {
        self.currentPage(1)
        self.updateQueryParams()
        console.log(self.searchName())
        console.log(self.selectedCategory())
        this.loadProducts()
    };

    self.clearFilters = () => {
        self.searchName(null)
        self.selectedCategory(0)

        console.log('TEST',self.selectedCategory())
        self.updateQueryParams()
        
    }
   
    self.deleteProduct = function (product) {
        if (confirm("Are you sure you want to delete this product?")) {

            $.ajax({
                url: `${config.BASE_URL}/api/product/${product.id}/delete`,
                type: 'DELETE',
                contentType: 'application/json',
                data: {},
                success: function (response) {
                    if (response) {
                        alert("Product deleted successfully.");
                        window.location.href = '/'
                        self.loadProducts();
                    } else {
                        alert("Failed to update product.");
                    }
                },
                error: function (error) {
                    console.error("Error updating product:", error);
                    alert("An error occurred while updating the product.");
                }
            });
        }
    };


    self.deleteCurrentProduct = function () {
        if (self.selectedProduct() && confirm("Are you sure you want to delete this product?")) {

            $.ajax({
                url: `${config.BASE_URL}/api/product/${self.selectedProduct().id}/delete`,
                type: 'DELETE',
                contentType: 'application/json',
                data: {},
                success: function (response) {
                    if (response) {
                        alert("Product deleted successfully.");
                        window.location.href = '/'
                        self.loadProducts(); 
                    } else {
                        alert("Failed to update product.");
                    }
                },
                error: function (error) {
                    console.error("Error updating product:", error);
                    alert("An error occurred while updating the product.");
                }
            });

            alert("Product deleted.");
        }
    };

    
    self.nextPage = function () {
        self.loadQueryParams()
        if (!self.currentPage())
            self.currentPage(1)
        if (self.currentPage() < self.totalPages()) { 
            self.currentPage(self.currentPage() + 1);
            self.updateQueryParams();
        }
    };

    self.previousPage = function () {
        if (self.currentPage() > 1) {
            self.currentPage(self.currentPage() - 1);
            self.updateQueryParams();   
        }
    };

    self.updateQueryParams = function () {
        const url = new URL(window.location);
        self.currentPage(self.currentPage() ?? 1)
        url.searchParams.set('page', self.currentPage());

        if (self.searchName()) {
            url.searchParams.set('name', self.searchName());
        } else {
            url.searchParams.delete('name')
        }

        if (self.selectedCategory()) {
            url.searchParams.set('category', self.selectedCategory());
        } else {
            url.searchParams.delete('category')
        }

        console.log(self.selectedCategory())
        window.history.pushState({}, '', url);
    };

    self.loadQueryParams = function () {
        const searchParams = new URLSearchParams(window.location.search);

        self.currentPage(searchParams.get('page') ? parseInt(searchParams.get('page')) : null);
        self.searchName(searchParams.get('name') || null);
        self.selectedCategory(searchParams.get('category') || null);
    };

    self.saveProduct = function () {
        if (self.selectedProduct()) {
            const updatedProduct = ko.toJS(self.selectedProduct());

            let updateBody = {
                code: updatedProduct.code,
                name: updatedProduct.name,
                price: updatedProduct.price,
                amount: updatedProduct.amount
            }



            if (self.newCategory()) {
                updateBody = {
                    ...updateBody,
                    category_name: self.newCategory(),
                }
            } else {
                updateBody = {
                    ...updateBody,
                    category_id: updatedProduct.category_id,
                }
            }

            console.log(self.imagePreview())

            if (self.imagePreview()) {
                updateBody.image = self.imagePreview()
            }

            console.log(updateBody)

            $.ajax({
                url: `${config.BASE_URL}/api/product/${updatedProduct.id}/update`,
                type: 'PUT',
                contentType: 'application/json',
                data: JSON.stringify(updateBody),
                success: function (response) {
                    if (response.result) {
                        alert("Product updated successfully.");
                        window.location.href = '/'
                        self.loadProducts(); 
                    } else {
                        alert("Failed to update product.");
                    }
                },
                error: function (error) {
                    console.error("Error updating product:", error);
                    alert("An error occurred while updating the product.");
                }
            });
        }
    };

    self.cancelEdit = function () {
        self.newCategory(null); 

        app.setLocation(`/product/${self.productId()}/detail`);
    };

    self.uploadImage = function (data, event) {
        var file = event.target.files[0]; 
        if (file) {
            var reader = new FileReader();

            reader.onload = function (e) {
                self.imagePreview(e.target.result); 
            };

            reader.readAsDataURL(file); 
        }
    };

    self.clearImage = function () {
        self.imagePreview(null); 
        document.getElementById('productImage').value = ''; 
    };

    self.createProduct = function () {
        const productData = ko.toJS(self.newProduct()); 

        let createBody = {
            code: productData.code,
            name: productData.name,
            price: productData.price,
            amount: productData.amount
        }

        //TODO: improve  validation 
        const existingProduct = self.products().find(function (product) {
            return product.code === productData.code;
        });

        if (existingProduct) {
            alert("Code already in use.");
            return
        }

        if (self.imagePreview()) {
            createBody.image = self.imagePreview()
        }

        //   if (self.newCategory()) {
        //       updateBody = {
        //           ...updateBody,
        //           category_name: self.newCategory(),
        //       }
        //   } else {
        createBody = {
            ...createBody,
            category_id: productData.category_id,
        }
        //}

        $.ajax({
            url: `${config.BASE_URL}/api/product/create`, 
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(createBody),
            success: function (response) {
                if (response.result) {
                    alert("Product created successfully.");
                    self.cancelCreate()
                } else {
                    alert("Failed to create product.");
                }
            },
            error: function (error) {
                console.error("Error creating product:", error);
                alert("An error occurred while creating the product.");
            }
        });
    };

    self.cancelCreate = function () {
        self.newProduct({
            name: ko.observable(''),
            code: ko.observable(''),
            price: ko.observable(0),
            amount: ko.observable(0),
            category_id: ko.observable(null),
            img_path: ko.observable(null)
        });
        app.setLocation('/');
    };


    self.addNewCategory = function () {
        const categoryName = self.newCategory().trim();

        if (categoryName && !self.categories().some(cat => cat.name.toLowerCase() === categoryName.toLowerCase())) {
            const newCategory = { id: Date.now(), name: categoryName }; 

            self.categories.push(newCategory); 

            self.selectCategory(newCategory);


            self.newCategory('');
            $('#categorySelect').SumoSelect({ placeholder: 'Select or add a category' }).sumo.reload();

        } else if (!categoryName) {
            alert("Please enter a valid category name.");
        } else {
            alert("This category already exists.");
        }
    };

    self.loadQueryParams();

    ko.bindingHandlers.sumoSelect = {
        init: function (element, valueAccessor, allBindings) {
            $(element).SumoSelect({
                search: true,
                searchText: 'Enter here.',
                noMatch: 'No Matches for "{0}"',
                placeholder: 'Select a category'
            });

            $(element).on('change', function () {
                $(element)[0].sumo.reload();
            });
        },
        update: function (element, valueAccessor) {
            $(element)[0].sumo.reload();
        }
    };
}

/** Sammy routing */
$(function () {
    var viewModel = new AppViewModel();

    app = Sammy(function () {

        this.get('/home', function () {
            viewModel.changeView('home'); 
        });

        this.get('/', function () {
            viewModel.changeView('home');
            viewModel.loadQueryParams()
            if (viewModel.categories().length == 0)
                viewModel.loadCategories()

            viewModel.loadProducts()
        });

        this.get('/product/add', () => {
            if (viewModel.categories().length == 0)
                viewModel.loadCategories()

            viewModel.changeView('product-add')
        });

        this.get('/product/:id/detail', function () {
            var productId = this.params.id; 
            viewModel.productId(productId); 
            viewModel.loadProductDetails()
            viewModel.changeView('product-detail'); 
        });

        this.get('/product/:id/edit', function () {
            var productId = this.params.id; 
            if (viewModel.categories().length == 0)
                viewModel.loadCategories()

            viewModel.productId(productId); 
            viewModel.loadProductDetails()
            viewModel.changeView('product-edit');
        });

        this.notFound = function () {
            viewModel.changeView('404');
        };

        ko.applyBindings(viewModel);
    });

    app.run();

    $('nav a, .pagination-controls button').on('click', function (e) {
        e.preventDefault(); 
        var path = $(this).attr('href');

        window.history.pushState(null, '', path);

        app.run(path);
    });
});


