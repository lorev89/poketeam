/**************************************************
 * Copyright (C) 2021 Forge S.r.l.
 * This file can not be copied and/or distributed
 * without the express permission of Forge S.r.l
 */

const messages = []
let messagesCount = 0
const messageLimit = 19 
const messageHistoryLength = 10
let ended = false

const botResponses = {
    "hi, how are you?" : "fine thanks!"
}

class Message {
    constructor(author, text) {
        this.author = author
        this.text = text
        this.date = new Intl.DateTimeFormat("it", { 
            timeStyle: "medium", 
            dateStyle: "medium" 
        }).format(new Date());
    }
}

function displayMessages() {
    const chatElement = document.getElementById('chat')
    chatElement.innerHTML = ""

    for (const message of messages) {

        const messageElement = document.createElement("div")

        messageElement.className =message.author === "Bot" ? "bot-message" : "user-message"

        const userNameElement = document.createElement("div")
        userNameElement.className = "author"
        userNameElement.innerText = message.author
        messageElement.appendChild(userNameElement)

        const dateElement = document.createElement("div")
        dateElement.className = "date"
        dateElement.innerText = message.date
        messageElement.appendChild(dateElement)

        const textElement = document.createElement("div")
        textElement.className = "text"
        textElement.innerText = message.text
        messageElement.appendChild(textElement)

        chatElement.appendChild(messageElement)
    }
    chatElement.scrollTop = chatElement.scrollHeight;
}


function getResponse(text) {
    return botResponses[text.toLowerCase()] || "Sorry I don't understand"
}


function postMessage(event) {
    event.preventDefault()

    if (ended) 
        return

    const text = event.target[0].value.trim()

    if (text === "") return

    if (messages.length >= messageHistoryLength) {
        messages.shift()
    }
    
    if (messagesCount < messageLimit) {
        messagesCount++
        messages.push(new Message("User", text))
    } else {
        messages.push(new Message("Bot", "Chat closed!"))
        ended = true
        event.target[0].value = ""
        displayMessages()
        return
    }
    
    event.target[0].value = ""
    displayMessages()

    const botResponse = getResponse(text)
    if (botResponse) {
        const statusElement = document.getElementById("status")
        statusElement.innerText = "I'm thinking about it.."
        statusElement.className = ""

        setTimeout(() => { 
            statusElement.className = "inactive"
            messages.push(new Message("Bot", botResponse))
            displayMessages()
        }, 2000)
    }
}