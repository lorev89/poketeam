/**************************************************
 * Copyright (C) 2021 Forge S.r.l.
 * This file can not be copied and/or distributed
 * without the express permission of Forge S.r.l
 */

const messages = []

class Message {
    constructor(author, text) {
        this.author = author
        this.text = text
    }
}

function displayMessages() {
    const chatElement = document.getElementById('chat')
    chatElement.innerHTML = ""

    for (const message of messages) {
        const messageElement = document.createElement("div")
        messageElement.className = "user-message"

        const userNameElement = document.createElement("div")
        userNameElement.className = "author"
        userNameElement.innerText = message.author
        messageElement.appendChild(userNameElement)

        const textElement = document.createElement("div")
        textElement.className = "text"
        textElement.innerText = message.text
        messageElement.appendChild(textElement)

        chatElement.appendChild(messageElement)
    }
    chatElement.scrollTop = chatElement.scrollHeight;
}

function postMessage(event) {
    event.preventDefault()

    const text = event.target[0].value
    messages.push(new Message("User", text))
    event.target[0].value = ""

    displayMessages()
}